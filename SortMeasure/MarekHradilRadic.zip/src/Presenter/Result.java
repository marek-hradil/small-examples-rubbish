package Presenter;

public interface Result {
    public String getName();

    public String getResult();
}