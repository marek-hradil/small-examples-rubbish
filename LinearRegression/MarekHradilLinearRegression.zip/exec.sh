#!/bin/bash

make gauss_jordan
chmod +x gauss_jordan
./gauss_jordan
rm -rf ./*.o